import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmR1YWxpdHk=')

name = b.b64decode('RHVhbGl0eQ==')

host = b.b64decode('aHR0cDovL29udGFyZ2V0LmxpdmU=')

port = b.b64decode('ODA4MA==')

host1 = b.b64decode('aHR0cDovL215YWxsdmlldy5jby51aw==')

port1 = b.b64decode('ODA=')