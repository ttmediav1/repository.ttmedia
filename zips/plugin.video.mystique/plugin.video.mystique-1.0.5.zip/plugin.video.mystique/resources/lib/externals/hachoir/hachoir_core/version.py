PACKAGE = "hachoir-core"
VERSION = "1.3.3"
WEBSITE = 'http://bitbucket.org/haypo/hachoir/wiki/hachoir-core'
LICENSE = 'GNU GPL v2'

