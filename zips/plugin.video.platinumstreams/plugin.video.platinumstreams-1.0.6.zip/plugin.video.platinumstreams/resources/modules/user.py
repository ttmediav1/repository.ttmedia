import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnBsYXRpbnVtc3RyZWFtcw==')

name = b.b64decode('UGxhdGludW0gU3RyZWFtcw==')

host = b.b64decode('aHR0cDovL3N0YXZyb3MubGlmZQ==')

port = b.b64decode('ODA4MA==')