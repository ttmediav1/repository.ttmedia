import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmJ0bWVkaWE=')

name = b.b64decode('Qk9TUy1URUNIIE1lZGlh')

host = b.b64decode('aHR0cDovL2xpbWl0bGVzcy1pcHR2LmlzLWZvdW5kLm9yZw==')

port = b.b64decode('MjU0NjE=')