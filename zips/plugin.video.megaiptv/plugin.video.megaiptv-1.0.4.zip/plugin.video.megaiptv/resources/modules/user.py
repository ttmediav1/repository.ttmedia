import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLm1lZ2FpcHR2')

name = b.b64decode('TWVnYSBJUFRW')

host = b.b64decode('aHR0cDovL215YWxsdmlldy5jby51aw==')

port = b.b64decode('ODA=')


