import xbmcaddon

MainBase = 'http://xray840.startdedicated.net/qsa/thunderstruck/rd/home.txt'
addon = xbmcaddon.Addon('plugin.video.rd')