
![](https://raw.githubusercontent.com/Kolifanes/plugin.video.youtube/master/icon.png)

![Build Status](https://img.shields.io/travis/jdf76/plugin.video.youtube/master.svg)
![License](https://img.shields.io/badge/license-GPL--2.0--only-success.svg)
![Kodi Version](https://img.shields.io/badge/kodi-isengard%2B-success.svg)
![Contributors](https://img.shields.io/github/contributors/jdf76/plugin.video.youtube.svg)

## Links

* [YouTube](http://www.youtube.com)
* [Support thread](http://forum.kodi.tv/showthread.php?tid=325740)
* [Wiki](https://github.com/jdf76/plugin.video.youtube/wiki)

---

![](https://i.imgur.com/fzPmDDJ.gif)

