import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLm1hZmlhc3RyZWFtcw==')

name = b.b64decode('TWFmaWEgU3RyZWFtcw==')

host = b.b64decode('aHR0cDovL29udGFyZ2V0LmxpdmU=')

port = b.b64decode('ODA4MA==')