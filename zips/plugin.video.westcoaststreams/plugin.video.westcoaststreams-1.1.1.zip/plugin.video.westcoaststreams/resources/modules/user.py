import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLndlc3Rjb2FzdHN0cmVhbXM=')

name = b.b64decode('V2VzdENvYXN0IFN0cmVhbXM=')

host = b.b64decode('aHR0cDovL3N0YXZyb3MubGlmZQ==')

port = b.b64decode('ODA4MA==')