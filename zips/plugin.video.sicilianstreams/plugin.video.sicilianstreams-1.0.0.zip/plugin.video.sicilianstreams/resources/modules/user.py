import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnNpY2lsaWFudHJlYW1z')

name = b.b64decode('U2ljaWxpYW4gU3RyZWFtcw==')

host = b.b64decode('aHR0cDovL215YWxsdmlldy5jby51aw==')

port = b.b64decode('ODA=')